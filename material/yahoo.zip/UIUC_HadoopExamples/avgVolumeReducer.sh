#!/bin/sh
awk 'BEGIN {sym = ""; count = 0; total = 0;} {if (sym != $1) { if (sym != "") {print sym  "\t" (total/count)} sym = $1; count = 0; total = 0} count = count + $2; total = total + $3} END {print sym  "\t" (total/count)}'
exit 0