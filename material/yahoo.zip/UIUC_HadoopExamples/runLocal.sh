#!/bin/sh
hadoop fs -cat NYSE-2000-2001.tsv | ./countAndSumVolumeFromOrig.sh | sort | ./avgVolumeReducer.sh | ./findTop10.py | sort | ./findTop10.py