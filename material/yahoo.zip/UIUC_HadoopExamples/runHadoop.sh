#!/bin/sh
hadoop fs -rm -r out tmp
hadoop jar /usr/lib/hadoop-mapreduce/hadoop-streaming.jar -input NYSE-2000-2001.tsv -output tmp -mapper countAndSumVolumeFromOrig.sh -reducer avgVolumeReducer.sh -file ./countAndSumVolumeFromOrig.sh -file ./avgVolumeReducer.sh
hadoop jar /usr/lib/hadoop-mapreduce/hadoop-streaming.jar -input tmp -output out -mapper ./findTop10.py -reducer ./findTop10.py -file ./findTop10.py
hadoop fs -cat out/\*
