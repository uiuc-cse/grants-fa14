#!/bin/sh
awk 'BEGIN {sym = ""; count = 0; total = 0;} {if (sym != $2) { if (sym != "") {print sym  "\t" count "\t" total} sym = $2; count = 0; total = 0} count = count + 1; total = total + $8} END {print sym  "\t" count "\t" total}'
