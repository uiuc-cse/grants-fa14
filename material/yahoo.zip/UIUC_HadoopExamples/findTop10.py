#!/usr/bin/python

import sys

top10 = []
for line in sys.stdin:
	parts = line.strip().split("\t")
	if len(parts) > 1:
		top10.append([float(parts[1]), parts[0]])
		top10 = sorted(top10)
		if len(top10) > 10:
			top10 = top10[-10:]

for item in top10:
	print item[1] + "\t" + str(item[0])

